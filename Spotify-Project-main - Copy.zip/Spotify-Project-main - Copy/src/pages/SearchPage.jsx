import React from 'react';
import { Profile } from "../components/ProfileButton";
import { SearchButton } from "./../components/SearchButton";
import { Playlist } from "./../components/Playlist";
import { Sidebar } from "../components/Sidebar";
import { Header } from '../components/Header';
import { SongCard } from '../components/SongCard';
import { Row } from '../components/Row';
import { PlayButton } from '../components/PlayButton';
import { GenreCard } from '../components/GenreCard';
import { Footer } from '../components/Footer';
import { SingUp } from '../components/SignupBar';

export const SearchPage = () => {
  const containerStyle = {
    backgroundColor: '#020617',
    display: 'flex',
    height: '110vh'
  };

  return (
    <div style={containerStyle}>
      <Sidebar />
      <div className="bg-slate-950 pt-4 px-2" style={{ width: "950px", height:"90vh " }}>
        <div className="bg-slate-900">
          <Header />
          <div className="overflow-y-auto text-white custom-scrollbar p-2" style={{ height: "450px" }}>
            <div className="bg-slate-900 text-left text-slate-100 font-semibold font-Raleway mt-4">
              <div >
                {/* THE SEARCH HISTORY SONGCARDS */}
                <Row title="Recent Searches"/>
              </div>
              {/* THE GENRE CARDS */}
              <GenreCard/>
            </div>
            <Footer/>
          </div>
        </div>
      </div>
    </div>
  );
};


