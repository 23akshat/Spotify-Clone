import { Link } from 'react-router-dom';
import React from 'react';
import { Profile } from './ProfileButton';

export const Sidebar = () => {
  return (
    <>
    <div className="m-0 h-auto w-3/12 py-4 pl-4 pr-2 bg-slate-950">
        <ul className="rounded-sm bg-slate-900 text-slate-300 p-4">
            <Link to="/homepage">
                <li className=" p-2"><img className="w-auto h-8 transition-colors duration-500 hover:bg-slate-700" src="https://imgs.search.brave.com/gAASQsi_SWZZJqpGrSlxBdrdObjjSOVwmUI09qMtkfg/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly9sb2dv/ZG93bmxvYWQub3Jn/L3dwLWNvbnRlbnQv/dXBsb2Fkcy8yMDE2/LzA5L3Nwb3RpZnkt/bG9nby1icmFuY2Et/d2hpdGUucG5n" alt="spotify-logo" /></li>
                <li className=" p-2 flex font-family-Raleway duration-200 ease-in font-semibold hover:text-slate-700 duration-500 "><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-house"><path d="M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8"/><path d="M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg><h4 className="ml-4">Home</h4></li>
            </Link>
            <Link to="/searchpage">
                <li className=" p-2 flex font-family-Raleway duration-200 ease-in font-semibold hover:text-slate-700 duration-500 "><svg className="h-6 w-auto icon glyph" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg><h4 className="ml-4">Search</h4></li>
            </Link>
        </ul>
        <ul className="rounded-sm bg-slate-900 text-slate-300 p-4 mt-2">
            <Link to="/playlist">
            <li className=" p-2 flex font-family-Raleway duration-200 ease-in font-semibold hover:text-slate-700 duration-500 "><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-library"><path d="m16 6 4 14"/><path d="M12 6v14"/><path d="M8 8v12"/><path d="M4 4v16"/></svg><h4 className="ml-4"></h4>
                    <h2>Your Library</h2>
                </li>
            </Link>
        </ul>
        <div className="overflow-y-auto text-white h-40 custom-scrollbar p-2">
                {/* Scrollable Section 1 */}
                <div className="my-2 p-4 bg-slate-600 text-left rounded-lg">
                    <h5 className="font-family-Raleway font-semibold">Create Your Playlist</h5>
                    <h5 className="font-family-Raleway">It is easy, we will help you!</h5><br></br>
                <Link to="/playlist" className="ml-4 duration-200 hover:text-slate-700 ease-in font-family-Raleway font-semibold text-black bg-white rounded-3xl p-2 shadow-lg transform transition-transform duration-200 hover:scale-105">
                Create Playlist+</Link>
                </div>
                <div className="my-4 p-4 bg-slate-600 text-left rounded-lg">
                    <h5 className="font-family-Raleway font-semibold">Find some Podcasts</h5>
                    <h5 className="font-family-Raleway">We have updated the episodes</h5><br></br>
                    <button className="font-family-Raleway font-semibold text-black bg-white rounded-3xl p-2 shadow-lg transform transition-transform duration-200 hover:scale-105">Browse Podcasts</button>
                </div>
                <div className="my-4 p-4 bg-slate-600 text-left rounded-lg">
                    <h5 className="font-family-Raleway font-semibold">Follow</h5>
                    <h5 className="font-family-Raleway">New artists you may like</h5><br></br>
                    <button className="font-family-Raleway font-semibold text-black bg-white rounded-3xl p-2 shadow-lg transform transition-transform duration-200 hover:scale-105">Browse Artists</button>
                </div>
        </div>
        <div>
            <div className="row text-white text-xs p-6 text-left">
                <div>Legal </div>
                <div>Safety & Privacy Center</div>
                <div>Privacy Policy</div>
                <div>Cookies</div>
                <div>About Ads</div>
                <div className="mt-4">
                    <button className="flex text-md font-semibold rounded-3xl border-2 border-slate-400 p-2 hover:border-white text-slate-400 hover:text-white">
                    <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/><path d="M2 12h20"/></svg>
                    &nbsp; English
                    </button>
                </div>
            </div>
        </div>
    </div>
    </>
  )
}
