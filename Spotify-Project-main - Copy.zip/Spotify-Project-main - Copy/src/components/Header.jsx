import { Link } from 'react-router-dom';
import React from 'react';
import { SearchButton } from './SearchButton';
import { SearchBar } from './SearchBar';

export const Header = () => {
  const styleButton = "font-semibold mx-2 p-2 rounded-full bg-slate-900 text-slate-400 hover:text-slate-100 hover:bg-slate-800";

  return (
    <div className='flex items-center border-black bg-slate-900 p-4'>
      <div className='flex text-white'>
        <button className={styleButton}>
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-step-back">
            <line x1="18" x2="18" y1="20" y2="4"/>
            <polygon points="14,20 4,12 14,4"/>
          </svg>
        </button>
        <button className={styleButton}>
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-step-forward">
            <line x1="6" x2="6" y1="4" y2="20"/>
            <polygon points="10,4 20,12 10,20"/>
          </svg>
        </button>
      </div>
      <div>
    <SearchButton/>
    </div>
     <SearchBar/> 
      <div className='flex text-white' style={{ marginLeft: "auto", alignItems: "center" }}>
        <Link to="/signUp" className={styleButton} style={{ margin: "0 10px" }}>
          Sign Up
        </Link>
        <Link to="/login" className="bg-white text-slate-900 font-semibold drop-shadow-lg px-4 py-2 rounded-full mx-2">
          Log In
        </Link>
      </div>
    </div>
  );
}
