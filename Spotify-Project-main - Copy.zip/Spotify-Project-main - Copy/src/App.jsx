import './App.css'
import {BrowserRouter as Router, Routes, Route} from "react-router-dom";
import { Homepage } from './pages/HomePage';
import {Login} from './pages/Login';
import { SignUp } from './pages/SignUp';
import {Library} from './pages/Library';
import { SearchPage } from './pages/SearchPage';
import { UserPage } from './pages/UserPage';


function App() {

  return (
    <>
    <Router>
      <Routes>
        <Route path="/" element={<Homepage />} />
        <Route path="/homepage" element={<Homepage/>} />
        <Route path="/searchpage" element={<SearchPage/>} />
        <Route path="/login" element={<Login/>} />
        <Route path="/signUp" element={<SignUp/>} />
        <Route path="/playlist" element={<Library/>}/>
        <Route path="/userpage" element={<UserPage/>}/>
      </Routes>
    </Router>
    </>
  )
}

export default App
